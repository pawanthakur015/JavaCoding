/**
 * 
 */
package com.pawan.test.constant;

/**
 * @author pawankumarthakur
 *
 */
public enum ParkingType {
	REGULAR, COMPACT,
}
