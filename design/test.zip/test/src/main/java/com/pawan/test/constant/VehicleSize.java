/**
 * 
 */
package com.pawan.test.constant;

/**
 * @author pawankumarthakur
 *
 */
public enum VehicleSize {
	MOTORCYCLE, COMPACT
}
